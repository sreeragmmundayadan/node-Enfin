import { Book } from './book.entity';

export const entities = [Book];
