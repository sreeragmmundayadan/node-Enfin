export const messages = {
  USER_NAME_REQUIRED: 'User Name is required',
};
